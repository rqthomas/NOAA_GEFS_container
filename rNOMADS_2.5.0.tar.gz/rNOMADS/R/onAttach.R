.onAttach <- function(libname, pkgname) {
   packageStartupMessage(paste0(c("\n****\nWelcome to rNOMADS 2.5.0 \"Captain Trips\"!\n",
   "Questions? Follow @rNOMADS_r on Twitter or send a message to rnomads-user@lists.r-forge.r-project.org\n",
   "Using rNOMADS as a data source for a publication?  Please cite it!\n",  
    "I'm an early career researcher and every citation matters.\n****\n")))
}
